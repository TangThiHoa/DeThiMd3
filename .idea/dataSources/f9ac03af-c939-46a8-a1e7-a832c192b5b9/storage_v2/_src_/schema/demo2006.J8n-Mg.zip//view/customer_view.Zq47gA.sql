create definer = root@localhost view customer_view as
select `demo2006`.`customer`.`name` AS `name`, `demo2006`.`customer`.`age` AS `age`
from `demo2006`.`customer`;

